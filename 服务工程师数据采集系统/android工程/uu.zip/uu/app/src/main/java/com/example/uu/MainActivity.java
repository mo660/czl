package com.example.uu;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import android.widget.TextView;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;

import cz.msebera.android.httpclient.Header;

@SuppressLint("NewApi")
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextName;
    private EditText userName;
    private EditText userNumber;
    private EditText errorInformation;
    private EditText addressInformation;
    private ImageView imgView;
    private String encodedString;
    private int RESULT_LOAD_IMG = 1;
    private RequestParams param = new RequestParams();
    private Bitmap bitmap;
    public LocationClient mLocationClient;
    private String currentPosition;
    private EditText gpsText;
    private Button gpsbb;
    private Button ww;
    private List<Uri> userSelectedImageUriList = null;
    private int size;
    private int imageNumber=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLocationClient = new LocationClient((getApplicationContext()));
        mLocationClient.registerLocationListener(new MyLocationListener());
        setContentView(R.layout.activity_main);

        editTextName = (EditText) findViewById(R.id.editText);
        userName = (EditText) findViewById(R.id.user);
        userNumber = (EditText) findViewById(R.id.number);
        errorInformation = (EditText) findViewById(R.id.error);
        imgView = (ImageView) findViewById(R.id.imageView);
        addressInformation = (EditText) findViewById(R.id.address);
        gpsText=(EditText)findViewById(R.id.gpsView);
        gpsbb=(Button)findViewById(R.id.gpsButton);
        gpsbb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestLocation();
            }
        });
        ww=(Button)findViewById(R.id.web);
        ww.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("http://192.168.43.119:8080/pp");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        findViewById(R.id.choose_image).setOnClickListener(this);
        findViewById(R.id.upload_image).setOnClickListener(this);
        findViewById(R.id.change_image).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.choose_image:
                loadImage();
                break;
            case R.id.upload_image:
                uploadImage();
                break;
            case R.id.change_image:
                lookImage();
                break;
        }
    }
    private void lookImage(){
        if( userSelectedImageUriList != null )
        {
            // Get current display image file uri.
            Uri currentUri = userSelectedImageUriList.get(imageNumber);
            ContentResolver contentResolver = getContentResolver();

            try {
                // User content resolver to get uri input stream.
                InputStream inputStream = contentResolver.openInputStream(currentUri);

                // Get the bitmap.
                Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);

                // Show image bitmap in imageview object.
                imgView.setImageBitmap(imgBitmap);

            }catch(FileNotFoundException ex)
            {
                Log.e("BROWSE_PICTURE", ex.getMessage(), ex);
            }

            // Get total user selected image count.
            if(imageNumber >= (size - 1) )
            {
                // Avoid array index out of bounds exception.
                imageNumber = 0;
            }else
            {
                imageNumber++;
            }
        }
    }
    /*初始化函数，并启动位置客户端LocationClient*/
    private void requestLocation() {
        initLocation();
        mLocationClient.start();
    }

    /*初始化函数*/
    private void initLocation() {
        LocationClientOption option = new LocationClientOption();

        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);
//可选，设置定位模式，默认高精度
//LocationMode.Hight_Accuracy：高精度；
//LocationMode. Battery_Saving：低功耗；
//LocationMode. Device_Sensors：仅使用设备；

        option.setCoorType("bd09ll");
//可选，设置返回经纬度坐标类型，默认GCJ02
//GCJ02：国测局坐标；
//BD09ll：百度经纬度坐标；
//BD09：百度墨卡托坐标；
//海外地区定位，无需设置坐标类型，统一返回WGS84类型坐标

        option.setScanSpan(1000);
//可选，设置发起定位请求的间隔，int类型，单位ms
//如果设置为0，则代表单次定位，即仅定位一次，默认为0
//如果设置非0，需设置1000ms以上才有效

        option.setOpenGps(true);
//可选，设置是否使用gps，默认false
//使用高精度和仅用设备两种定位模式的，参数必须设置为true

        option.setLocationNotify(true);
//可选，设置是否当GPS有效时按照1S/1次频率输出GPS结果，默认false

        option.setIgnoreKillProcess(false);
//可选，定位SDK内部是一个service，并放到了独立进程。
//设置是否在stop的时候杀死这个进程，默认（建议）不杀死，即setIgnoreKillProcess(true)

        option.SetIgnoreCacheException(false);
//可选，设置是否收集Crash信息，默认收集，即参数为false

        option.setWifiCacheTimeOut(5*60*1000);
//可选，V7.2版本新增能力
//如果设置了该接口，首次启动定位时，会先判断当前Wi-Fi是否超出有效期，若超出有效期，会先重新扫描Wi-Fi，然后定位

        option.setEnableSimulateGps(false);
//可选，设置是否需要过滤GPS仿真结果，默认需要，即参数为false

        option.setNeedNewVersionRgc(true);
//可选，设置是否需要最新版本的地址信息。默认需要，即参数为true

        mLocationClient.setLocOption(option);
//mLocationClient为第二步初始化过的LocationClient对象
//需将配置好的LocationClientOption对象，通过setLocOption方法传递给LocationClient对象使用
//更多LocationClientOption的配置，请参照类参考中LocationClientOption类的详细说明
    }
    //监听且显示经纬度
    public class MyLocationListener implements BDLocationListener {
        @Override
        public void onReceiveLocation(BDLocation location) {
            currentPosition = "纬度："+location.getLatitude()+"  "+"经度："+location.getLongitude();
            gpsText.setText(currentPosition);
        }
    }

    public void loadImage() {
        //这里就写了从相册中选择图片，相机拍照的就略过了
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, RESULT_LOAD_IMG);
    }

    //当图片被选中的返回结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == RESULT_LOAD_IMG && resultCode == RESULT_OK && null != data) {

                Uri selectedImage = data.getData();
                if(userSelectedImageUriList == null)
                {
                    userSelectedImageUriList = new ArrayList<Uri>();
                }
                userSelectedImageUriList.add(selectedImage);
                size = userSelectedImageUriList.size();

                /*String[] filePathColumn = { MediaStore.Images.Media.DATA };
                // 获取游标
                System.out.println("ssssssssssssssssssssssssssssssssss");
                Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                int columnIndex = cursor.getColumnIndexOrThrow(filePathColumn[0]);
                cursor.moveToFirst();
                imgPath = cursor.getString(columnIndex);
                cursor.close();
                System.out.println(imgPath);*/
                ContentResolver contentResolver = getContentResolver();
                try {
                    // User content resolver to get uri input stream.
                    InputStream inputStream = contentResolver.openInputStream(selectedImage);

                    // Get the bitmap.
                    Bitmap imgBitmap = BitmapFactory.decodeStream(inputStream);

                    // Show image bitmap in imageview object.
                    imgView.setImageBitmap(imgBitmap);

                }catch(FileNotFoundException ex)
                {
                    Log.e("BROWSE_PICTURE", ex.getMessage(), ex);
                }

            } else {
                Toast.makeText(this, "You haven't picked Image",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
    }

    //开始上传图片
    private void uploadImage() {
        if (userSelectedImageUriList!= null) {
            encodeImagetoString();
        } else {
            Toast.makeText(getApplicationContext(), "You must select image from gallery before you try to upload",
                    Toast.LENGTH_LONG).show();
        }
    }


    public void encodeImagetoString() {
        new AsyncTask<Void, Void, String>() {
            protected void onPreExecute() {
            };
            @Override
            protected String doInBackground(Void... params) {
                try {
                    BitmapFactory.Options options = null;
                    options = new BitmapFactory.Options();
                    options.inSampleSize = 3;
                    byte[] byte_arr;
                    // 压缩图片
                    for (int i=0;i<=size-1;i++) {
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        Uri currentUri = userSelectedImageUriList.get(i);
                        Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), currentUri);
                        bmp.compress(Bitmap.CompressFormat.JPEG, 40, stream);
                        byte_arr = stream.toByteArray();
                        // Base64图片转码为String
                        encodedString = Base64.encodeToString(byte_arr, 0);
                        param.put(String.valueOf(i), encodedString);
                    }
                }catch (IOException e) {
                    e.printStackTrace();
                }
                return "";
            }

            @Override
            protected void onPostExecute(String msg) {
                // 将转换后的图片添加到上传的参数中
                param.put("size",String.valueOf(size));
                param.put("filename", editTextName.getText().toString().trim());
                param.put("userName", userName.getText().toString().trim());
                param.put("userNumber", userNumber.getText().toString().trim());
                param.put("errorInformation",errorInformation.getText().toString().trim());
                param.put("addressInformation", addressInformation.getText().toString().trim());
                param.put("gps", currentPosition);
                // 上传图片
                connectionURL();
            }
        }.execute(null, null, null);
    }

    public void connectionURL() {
        String url = "http://192.168.43.119:8080/pp/zhu/LoginServlet";
        HttpUtil.post(url, param, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                if (statusCode == 200) {
                    try {
                        if (response.getBoolean("msg") == true) {
                            Toast.makeText(MainActivity.this, "上传成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "上传失败！", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

    }
}

    /*public void imageUpload() {
        prgDialog.setMessage("Invoking JSP");
        String url = "http://10.0.2.2:8080/pp/zhu/LoginServlet";
        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] bytes) {
                prgDialog.hide();
                Toast.makeText(getApplicationContext(), "upload success", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] bytes, Throwable throwable) {
                prgDialog.hide();
                if (statusCode == 404) {
                    Toast.makeText(getApplicationContext(),
                            "Requested resource not found", Toast.LENGTH_LONG).show();
                }
                // 当 Http 响应码'500'
                else if (statusCode == 500) {
                    Toast.makeText(getApplicationContext(),
                            "Something went wrong at server end", Toast.LENGTH_LONG).show();
                }
                // 当 Http 响应码 404, 500
                else {
                    Toast.makeText(
                            getApplicationContext(), "Error Occured n Most Common Error: n1. Device " +
                                    "not connected to Internetn2. Web App is not deployed in App servern3." +
                                    " App server is not runningn HTTP Status code : "
                                    + statusCode, Toast.LENGTH_LONG).show();
                }
            }
        });
    }*/