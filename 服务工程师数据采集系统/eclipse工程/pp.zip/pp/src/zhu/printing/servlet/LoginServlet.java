package zhu.printing.servlet;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;

import com.mysql.jdbc.PreparedStatement;

import net.sf.json.JSONObject; 
import zhu.printing.unit.ToolMySQLConnection;
import zhu.printing.unit.UploadImage;

public class LoginServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@SuppressWarnings({ "null", "unused" })
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		String size=request.getParameter("size");
		String fileName = request.getParameter("filename");
		String userName = request.getParameter("userName");
		String userNumber = request.getParameter("userNumber");
		String errorInformation = request.getParameter("errorInformation");
		String addressInformation = request.getParameter("addressInformation");
		String Latitude = request.getParameter("gps");
		int a=Integer.parseInt(size);
		String path="";
		for (int i = 0; i < a; i++) {
			String	imgEncodedStr=request.getParameter(String.valueOf(i));
			byte[] imageByteArray = Base64.decodeBase64(imgEncodedStr);
			FileOutputStream imageOutFile = new FileOutputStream("D:/uploads/" + fileName+"_"+String.valueOf(i)+".jpg");
			imageOutFile.write(imageByteArray);
			imageOutFile.close();
			path=path+"/uploads/" + fileName+"_"+String.valueOf(i)+".jpg-";
		}
		Connection con=null;
		String sql = "insert into test.information (edittext,username,usernumber,error,address,Latitude,picture) values (?,?,?,?,?,?,?)";
		PreparedStatement stmt;
		try {  
			con=ToolMySQLConnection.getConnection();  
			stmt = (PreparedStatement) con.prepareStatement(sql);
			stmt.setString(1, fileName);
			stmt.setString(2, userName);
			stmt.setString(3, userNumber);
			stmt.setString(4, errorInformation);
			stmt.setString(5, addressInformation);
			stmt.setString(6, Latitude);
			stmt.setString(7, path);
			stmt.executeUpdate();
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		System.out.println(path);
		System.out.println("Filename: "+ fileName);
		System.out.println("userName: "+userName);
		System.out.println("userNumber: "+ userNumber);
		System.out.println("errorInformation: "+ errorInformation);
		System.out.println("addressInformation: "+ addressInformation);
		boolean type=true;
		PrintWriter out = response.getWriter(); 
		
		JSONObject json = new JSONObject();
		json.put("msg",  type ); 
			//json.put("msg", JSONArray.fromObject(type,jsonConfig)); 
		response.getWriter().write(json.toString());
		out.flush();  
		out.close(); 
	}
	/*String ID = request.getParameter("ID"); //用于接收android前台的输入的值，此处参数必须要与你前台的值相对应
	        String PW= request.getParameter("PW");
	        boolean type=false;//用于判断账号和密码是否与数据库中查询结果一致  
	        response.setContentType("text/html; charset=UTF-8");  
	        PrintWriter out = response.getWriter();  
	        Connection con=null;
	        JSONObject json = new JSONObject();
	       //   JsonConfig jsonConfig = new JsonConfig();
	       // jsonConfig.registerJsonValueProcessor(java.sql.Date.class,new JsonDateValueProcessor());
	        try  
	        {  
	            con=ToolMySQLConnection.getConnection();  
	            Statement stmt=con.createStatement();  
	            String sql="select * from printing.sys_staff where Account="+ID+" and Password="+PW;  
	            ResultSet rs=stmt.executeQuery(sql);  
	            while(rs.next())  
	            {  
	                type=true;  	               
	            }  
	        }  
	        catch(Exception ex)  
	        {  
	            ex.printStackTrace();  
	        }  
	        finally  
	        {  
	        	ToolMySQLConnection.Close(null, null, con);
	        	json.put("msg",  type ); 
	            //json.put("msg", JSONArray.fromObject(type,jsonConfig)); 
	            response.getWriter().write(json.toString());
	            out.flush();  
	            out.close();  
	        }  
	}*/

}
