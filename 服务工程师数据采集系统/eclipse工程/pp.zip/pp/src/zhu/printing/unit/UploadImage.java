package zhu.printing.unit;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import org.apache.tomcat.util.codec.binary.Base64;

import com.mysql.jdbc.PreparedStatement;
import zhu.printing.unit.ToolMySQLConnection;

public class UploadImage {
	static boolean yesOrNo;
	public static boolean wheatherTure() {
		return yesOrNo;
	}

	public static void convertStringtoImage(String encodedImageStr, String fileName,String userName,
			String userNumber,String errorInformation,String addres,String Latitude) {

		Connection con=null;
		String sql = "insert into test.information (edittext,username,usernumber,error,address,Latitude,picture) values (?,?,?,?,?,?,?)";
		PreparedStatement stmt;
		try {  
			con=ToolMySQLConnection.getConnection();  
			stmt = (PreparedStatement) con.prepareStatement(sql);
			stmt.setString(1, fileName);
			stmt.setString(2, userName);
			stmt.setString(3, userNumber);
			stmt.setString(4, errorInformation);
			stmt.setString(5, addres);
			stmt.setString(6, Latitude);
			for(int i=0;i<i;i++) {
			byte[] imageByteArray = Base64.decodeBase64(encodedImageStr);
			FileOutputStream imageOutFile = new FileOutputStream("D:/uploads/" + fileName+"_"+String.valueOf(i)+".jpg");
			imageOutFile.write(imageByteArray);
			imageOutFile.close();
			stmt.setString(7, "/uploads/" + fileName+"_"+String.valueOf(i)+".jpg-");
			}
			stmt.executeUpdate();
			yesOrNo=true;
			
		} catch (FileNotFoundException fnfe) {
			System.out.println("Image Path not found" + fnfe);
		} catch (IOException ioe) {
			System.out.println("Exception while converting the Image " + ioe);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}